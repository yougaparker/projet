import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private TextView titreTextView;
    private TextView auteurTextView;
    private TextView dateTextView;
    private TextView textTextView2;
    private FloatingActionButton icBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        titreTextView = findViewById(R.id.titreTextView);
        auteurTextView = findViewById(R.id.auteurTextView);
        dateTextView = findViewById(R.id.dateTextView);
        textTextView2 = findViewById(R.id.textTextView2);
        icBack = findViewById(R.id.ic_back);

        icBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Action à effectuer lors du clic sur le bouton icBack
            }
        });

        // Vous pouvez ajouter ici du code supplémentaire pour initialiser les valeurs des TextView ou ajouter des fonctionnalités supplémentaires.
    }

    // Vous pouvez ajouter ici des méthodes supplémentaires pour gérer les événements ou ajouter des fonctionnalités spécifiques à votre application.

}
