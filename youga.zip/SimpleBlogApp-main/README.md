# SimpleBlogApp
A very simple mobile application that allows to add blogs, developed with Java and Android Studio

## Technology

SimpleBlogApp uses the following technologies:

- Java and Android Studio
- SQLite for the database

## Features
- Add Blogs
- View blog details


## Authors
Youga faly cissé
Mame mbodj fall
